import { readTelegramReturn, onTelegramAuth, showProfile } from "./app.js";

window.onTelegramAuth = onTelegramAuth;
var tgReturn = readTelegramReturn();
if (tgReturn) onTelegramAuth(tgReturn); else showProfile();
