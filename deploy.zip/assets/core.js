
const SUPABASE_URL = "https://xwnjimsoframcqstdjfo.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh3bmppbXNvZnJhbWNxc3RkamZvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk4NTAwODgsImV4cCI6MjEwNTQyNjA4OH0.JhyVa4l8qhK3_ZklbvJsK8fYvPyyWuCGeGzvZR6qu7c";
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
const $ = (id) => document.getElementById(id);
/* الرسائل تختفي بعد 5 ثواني (إلا لو keep) */
let sayTimer = null;
function say(t, keep) {
  $("msg").textContent = t;
  clearTimeout(sayTimer);
  if (t) sayTimer = setTimeout(() => { $("msg").textContent = ""; }, 5000);
}
function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}
function showLoading(on) { $("loading").hidden = !on; }
/* المظهر */
// المظهر تلقائي دائمًا: يتبع إعداد مظهر الجهاز (Light / Dark).
// لا يوجد اختيار يدوي للمظهر.
const theme = "auto";
try { localStorage.removeItem("theme"); } catch (e) {}
document.documentElement.removeAttribute("data-theme");
/* التوقيت (توقيت مصر) */
const dateFmt = new Intl.DateTimeFormat("en-US", {
  timeZone: "Africa/Cairo", dateStyle: "full", timeStyle: "short",
});
const dateOnlyFmt = new Intl.DateTimeFormat("en-US", {
  timeZone: "Africa/Cairo", dateStyle: "full",
});
const logFmt = new Intl.DateTimeFormat("en-US", {
  timeZone: "Africa/Cairo", dateStyle: "medium", timeStyle: "short",
});
function fmt(iso) { return dateFmt.format(new Date(iso)); }
function fmtDeadline(it) { return it.deadline_has_time === false ? dateOnlyFmt.format(new Date(it.deadline)) : fmt(it.deadline); }
function tzOffset(ms) {
  const p = {};
  new Intl.DateTimeFormat("en-US", {
    timeZone: "Africa/Cairo", hourCycle: "h23", year: "numeric", month: "2-digit",
    day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit",
  }).formatToParts(new Date(ms)).forEach((x) => { p[x.type] = x.value; });
  return Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second)
    - Math.floor(ms / 1000) * 1000;
}
function localToISO(v) {
  if (!v) return null;
  v = String(v).trim();
  if (!v) return null;

  let d = "", t = "23:59";
  if (v.includes("T")) {
    const parts = v.split("T");
    d = parts[0];
    t = parts[1] || "23:59";
  } else if (v.includes(" ")) {
    const parts = v.split(" ");
    d = parts[0];
    t = parts[1] || "23:59";
  } else {
    d = v;
    t = "23:59";
  }

  const dateParts = d.split("-").map(Number);
  if (dateParts.length < 3 || dateParts.some(isNaN)) {
    try {
      const parsed = new Date(v);
      return isNaN(parsed.getTime()) ? null : parsed.toISOString();
    } catch (e) {
      return null;
    }
  }

  const [y, m, da] = dateParts;
  const timeParts = t.split(":").map(Number);
  const h = isNaN(timeParts[0]) ? 23 : timeParts[0];
  const mi = isNaN(timeParts[1]) ? 59 : timeParts[1];

  const base = Date.UTC(y, m - 1, da, h, mi);
  let ms = base - tzOffset(base);
  ms = base - tzOffset(ms);
  return new Date(ms).toISOString();
}
function toLocalInput(iso) {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    const ms = d.getTime();
    return new Date(ms + tzOffset(ms)).toISOString().slice(0, 16);
  } catch (e) {
    return "";
  }
}
function safeUrl(u) {
  try {
    const x = new URL(u);
    return (x.protocol === "https:" || x.protocol === "http:") ? x.href : null;
  } catch (e) { return null; }
}
/* المرفقات */
const MAX_ATTACH = 10 * 1024 * 1024;
const WARN_ATTACH = 5 * 1024 * 1024;
const SHRINK_IMAGES = true; // تصغير الصور تلقائيًا قبل الرفع (اجعلها false لإيقافه)
async function shrinkImage(file) {
  const okTypes = ["image/jpeg", "image/png", "image/webp"];
  if (!SHRINK_IMAGES || !okTypes.includes(file.type) || file.size < 400 * 1024) return file;
  try {
    const bmp = await createImageBitmap(file);
    const max = 1600;
    const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
    const w = Math.round(bmp.width * k), h = Math.round(bmp.height * k);
    const cv = document.createElement("canvas");
    cv.width = w; cv.height = h;
    const cx = cv.getContext("2d");
    cx.fillStyle = "#fff";
    cx.fillRect(0, 0, w, h);
    cx.drawImage(bmp, 0, 0, w, h);
    if (bmp.close) bmp.close();
    const blob = await new Promise((r) => cv.toBlob(r, "image/jpeg", 0.82));
    if (!blob || blob.size >= file.size) return file;
    return new File([blob], file.name.replace(/\.[^.]+$/, "") + ".jpg", { type: "image/jpeg" });
  } catch (e) { return file; }
}
function humanSize(n) {
  if (n == null) return "";
  if (n < 1024 * 1024) return Math.round(n / 1024) + " ك.ب";
  return (n / (1024 * 1024)).toFixed(1) + " م.ب";
}
async function uploadAttachment(sectionId, file) {
  const safeName = file.name.replace(/[^\w.\-]+/g, "_").slice(-80);
  const path = sectionId + "/" + Date.now() + "_" + safeName;
  const { error } = await sb.storage.from("attachments")
    .upload(path, file, { contentType: file.type || "application/octet-stream" });
  if (error) return { error };
  const { data } = sb.storage.from("attachments").getPublicUrl(path);
  return {
    data: {
      attachment_kind: "file", attachment_path: path, attachment_url: data.publicUrl,
      attachment_name: file.name, attachment_mime: file.type || "application/octet-stream",
      attachment_size: file.size,
    },
  };
}
async function removeAttachmentFiles(paths) {
  const list = paths.filter(Boolean);
  if (!list.length) return;
  try { await sb.storage.from("attachments").remove(list); } catch (e) {}
}
async function uploadQAAttachment(file) {
  file = await shrinkImage(file);
  const safeName = file.name.replace(/[^\w.\-]+/g, "_").slice(-80);
  const path = "qa/" + Date.now() + "_" + safeName;
  const { error } = await sb.storage.from("attachments")
    .upload(path, file, { contentType: file.type || "application/octet-stream" });
  if (error) return { error };
  const { data } = sb.storage.from("attachments").getPublicUrl(path);
  return {
    data: {
      attachment_url: data.publicUrl, attachment_path: path,
      attachment_name: file.name, attachment_mime: file.type || "application/octet-stream",
      attachment_size: file.size,
    },
  };
}
function renderQAAttachment(obj) {
  if (!obj.attachment_url) return null;
  const wrap = el("div");
  const mime = obj.attachment_mime || "";
  if (mime.startsWith("image/")) {
    const img = el("img");
    img.src = obj.attachment_url;
    img.style.maxWidth = "100%";
    img.style.borderRadius = "8px";
    wrap.appendChild(img);
  } else if (mime.startsWith("video/")) {
    const v = el("video");
    v.src = obj.attachment_url;
    v.controls = true;
    v.style.maxWidth = "100%";
    wrap.appendChild(v);
  } else if (mime === "application/pdf") {
    const f = el("iframe");
    f.src = obj.attachment_url;
    f.style.width = "100%";
    f.style.height = "60vh";
    f.style.border = "2px solid var(--line)";
    f.style.borderRadius = "8px";
    wrap.appendChild(f);
  }
  const box = el("div", "row");
  const open = el("a", "btn", "↗️ فتح في نافذة جديدة");
  open.href = obj.attachment_url;
  open.target = "_blank";
  open.rel = "noopener noreferrer";
  box.appendChild(open);
  const dl = el("a", "btn", "⬇️ تحميل" + (obj.attachment_size ? " (" + humanSize(obj.attachment_size) + ")" : ""));
  dl.href = obj.attachment_url + (obj.attachment_url.includes("?") ? "&" : "?")
    + "download=" + encodeURIComponent(obj.attachment_name || "");
  dl.rel = "noopener noreferrer";
  box.appendChild(dl);
  wrap.appendChild(box);
  return wrap;
}

export {
  sb, $, say, el, showLoading, fmt, fmtDeadline, logFmt, tzOffset, localToISO, toLocalInput, safeUrl,
  MAX_ATTACH, WARN_ATTACH, SHRINK_IMAGES, shrinkImage, humanSize,
  uploadAttachment, removeAttachmentFiles, uploadQAAttachment, renderQAAttachment
};
